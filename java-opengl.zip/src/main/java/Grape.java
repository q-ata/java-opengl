
public class Grape extends MapItem {

  public Grape() {
    super(Figure.CUBE, Transformation.GRAPE, Sprite.GRAPE, GrapeInstance.class);
  }

}
