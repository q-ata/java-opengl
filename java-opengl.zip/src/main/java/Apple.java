
public class Apple extends MapItem {

  public Apple() {
    super(Figure.CUBE, Transformation.APPLE, Sprite.APPLE, AppleInstance.class);
  }
  
}
