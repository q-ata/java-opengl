public interface KeyPressCallback {

  public void run(boolean press);

}