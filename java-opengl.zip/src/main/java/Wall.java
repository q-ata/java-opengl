public class Wall extends MapItem {
  public Wall() {
    super(Figure.CUBE, Transformation.WALL, Sprite.WALL, WallInstance.class);
  }
}
